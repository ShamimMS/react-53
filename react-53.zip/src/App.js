import React, { useEffect } from 'react';
import './App.css';

function App(props) {
  useEffect(() => {
    const search = window.location.search;
    const params = new URLSearchParams(search);
    const data = params.get('data');
    const obj = JSON.parse(data);
    KarmaForm(obj);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const postInput = (id, val) => {
    const element1 = document.createElement('input');
    element1.value = val;
    element1.name = id;
    return element1;
  };
  const KarmaForm = (x) => {
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = 'https://staging.reversesoftonline.com/ApplyNow/?lof=CSTC&loginByUsingView=GS';

    form.appendChild(postInput('extRefId', x.refId));
    form.appendChild(postInput('extCampaingId', x.campaignId));
    form.appendChild(postInput('extCreditScore', x.creditScore));
    form.appendChild(postInput('extLeadSource', x.LeadSource));
    form.appendChild(postInput('extDownPaymentInDollars', x.downPaymentInDollars));
    form.appendChild(postInput('extEmail', x.email));
    form.appendChild(postInput('extFirstName', x.firstName));
    form.appendChild(postInput('extHomeBuyingProcessStatus', x.homeBuyingProcessStatus));
    form.appendChild(postInput('extIsMilitary', x.isMilitary));
    form.appendChild(postInput('extLastName', x.lastName));
    form.appendChild(postInput('extLoanAmount', x.loanAmount));
    form.appendChild(postInput('extPaymentType', x.loanProgram));
    form.appendChild(postInput('extPhone', x.phoneNumber));
    form.appendChild(postInput('extPropertyType', x.propertyType));
    form.appendChild(postInput('extPropertyOccupancy', x.propertyUse));
    form.appendChild(postInput('extPurchasePriceInDollars', x.purchasePriceInDollars));
    form.appendChild(postInput('extLoanPurpose', x.purpose));
    form.appendChild(postInput('extPropertyState', x.state));
    form.appendChild(postInput('extWorkingWithRealEstate', x.workingWithRealEstate));
    form.appendChild(postInput('extPropertyZip', x.zipCode));
    form.appendChild(postInput('extLoanType', x.loanType));

    // // The below two categories are mutually exclusive. Meaning that only one of the groups will be used.
    // // Purchase related
    // postInput("extLoanAmount",        $("#loanAmount").val()) +
    // postInput("extPurchasePrice",     $("#purchasePrice").val()) +
    // postInput("extDownPayment",       $("#downPayment").val()) +
    // // Refinance related
    // postInput("extLoanAmount",        $("#loanBalance").val()) +
    // postInput("extAppraisalAmount",   $("#propertyValue").val()) +
    // postInput("extCashOutAmount",     $("#cashOutAmount").val()) +

    document.body.appendChild(form);

    form.submit();
  };
  return (
    <>
      <div className="App">
        <div className="loader"></div>
      </div>
    </>
  );
}

export default App;
